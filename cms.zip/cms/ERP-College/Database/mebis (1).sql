-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2021 at 05:59 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mebis`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `library_name` varchar(255) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `book_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`library_name`, `book_name`, `author`, `book_status`) VALUES
('North Campus Library', 'Basics of Database', 'Reda Alhajj', 'Unavailable'),
('North Campus Library', 'Harry Potter', 'J. K. Rowling', 'Available'),
('North Campus Library', 'Lord of The Rings', 'J.R.R Tolkien', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_name` varchar(255) NOT NULL,
  `AKTS` int(255) NOT NULL,
  `class_no` varchar(255) NOT NULL,
  `course_type` varchar(255) NOT NULL,
  `lecturer` varchar(255) NOT NULL,
  `prerequisite` varchar(255) NOT NULL,
  `semester` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_name`, `AKTS`, `class_no`, `course_type`, `lecturer`, `prerequisite`, `semester`) VALUES
('Algorithm', 8, 'C-210', 'Technical', 'S.K Rathod', 'Data Structures', 'Summer'),
('Calculus 1', 8, 'CZ-16', 'Technical', 'J.K Singh', 'NULL', 'Spring'),
('Calculus 2', 8, 'CZ-16', 'Technical', 'Vinay Thakur', 'Calculus 1', 'Winter'),
('Data Structures', 8, 'C-310', 'Technical', 'Anil kumar Meher', 'Object Oriented Programming', 'Winter'),
('Database', 8, 'C-210', 'Technical', 'Akash Kumar', 'Object Oriented Programming', 'Spring'),
('Introduction to Programming', 6, 'C-211', 'Technical', 'Rabi Narayan Das', 'NULL', 'Summer'),
('Machine Learning', 6, 'C-313', 'Non-Technical', 'Sunil Rathod', 'NULL', 'Summer'),
('Microprocessor', 6, 'C-210', 'Technical', 'Naveen Sikhera', 'Introduction to Programming', 'Winter'),
('Object Oriented Programming', 8, 'C-212', 'Technical', 'Lohitang Sharma', 'Introduction to Programming', 'Summer'),
('Probability', 8, 'CZ-12', 'Technical', 'Aham Sharma', 'Calculus 2', 'Spring'),
('Web Design', 8, 'C-315', 'Non technical', 'Debashish Rath', 'NULL', 'Spring');

-- --------------------------------------------------------

--
-- Table structure for table `dining`
--

CREATE TABLE `dining` (
  `id` int(11) NOT NULL,
  `Day` varchar(25) DEFAULT NULL,
  `dining_name` varchar(255) NOT NULL,
  `soup` varchar(255) NOT NULL,
  `main_dish` varchar(255) NOT NULL,
  `side_dish` varchar(255) NOT NULL,
  `dessert` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dining`
--

INSERT INTO `dining` (`id`, `Day`, `dining_name`, `soup`, `main_dish`, `side_dish`, `dessert`) VALUES
(1, 'Monday', 'Central Mess', 'Veg Soup', 'Rice,Dal,Ghanto,Veg Fry', 'Dhokla,Green chutney', 'Mysore pak,Milk cake,Chena poda'),
(2, 'Tuesday', 'Central Mess', 'Non veg Soup', 'Chicken Biriyani,Raita,Chicken Curry', 'Mughlai,Dhuska,Litthi Chokha', 'Pudding,Ice cream'),
(3, 'Wednesday', 'Central Mess', 'Manchow Soup', 'Roti,Pulaw,Dal Fry,Matar Paneer', 'Vada-Sambar', 'Rasgulla'),
(4, 'Thursday', 'Central Mess', 'Veg-Soup', 'Roti,Rice,Dal,Bhaja,Dry-sbji', 'Dosa,Idli', 'Kheer'),
(5, 'Friday', 'Central Mess', 'Hot&Sour soup', 'Roti,Rice,Dal,Chicken,Paneer', 'Aaloo Bada', 'Balusahi'),
(6, 'Saturday', 'Central Mess', 'Corn Soup', 'Veg-biryani,Raita', 'Samosa,sbji', 'Milk-cake'),
(7, 'Sunday', 'Central Mess', 'Tomato Soup', 'Roti,Rice,Fish,Channa-Chola', 'Chicken-Pakoda', 'kheer');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `course_name` varchar(255) NOT NULL,
  `exam_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`course_name`, `exam_name`) VALUES
('Algorithm', 'Algorithm Final'),
('Algorithm', 'Algorithm Midterm'),
('Database', 'Database Final'),
('Database', 'Database Midterm');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lecturer_name` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `birthdate` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `advised_st_id` int(255) NOT NULL,
  `department` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`lecturer_name`, `website`, `birthdate`, `email`, `degree`, `role`, `course_name`, `advised_st_id`, `department`) VALUES
('Aham Sharma', '', '2001-12-14', 'ahamsharma@giet.edu', 'Dr', 'lecturer', 'Probability', 110, 'Cse'),
('Akash Kumar', '', '1995-09-13', 'akashkumar@giet.edu', 'Dr', 'lecturer', 'Database', 105, 'Cse'),
('Anil kumar Meher', '', '1990-12-14', 'anilkumarmeher@giet.edu', 'Dr', 'lecturer', 'Data Structures', 104, 'Cse'),
('Debashish Rath', '', '2001-12-14', 'debashishrath@giet.edu', 'Dr', 'lecturer', 'Web Design', 111, 'Cse'),
('J.K Singh', '', '2001-11-10', 'j.ksingh@giet.edu', 'Dr', 'lecturer', 'Calculus 1', 102, 'Cse'),
('Lohitang Sharma', '', '1991-12-14', 'lohitangsharma@giet.edu', 'Dr', 'lecturer', 'Object Oriented Programming', 109, 'Cse'),
('Naveen Sikhera', '', '1981-04-04', 'naveensikhera@giet.edu', 'Dr', 'lecturer', 'Microprocessor', 108, 'Cse'),
('Rabi Narayan Das', '', '1985-01-01', 'rabinarayandas@giet.edu', 'Dr', 'lecturer', 'Introduction to Programming', 106, 'Cse'),
('S.K Rathod', '', '2001-12-14', 's.krathod@giet.edu', 'Dr', 'lecturer', 'Algorithm', 101, 'Cse'),
('Sunil Rathod', '', '1994-07-28', 'sunilrathod@giet.edu', 'Dr', 'lecturer', 'Machine Learning', 107, 'Cse'),
('Vinay Thakur', '', '2000-02-14', 'vinaythakur@giet.edu', 'Dr', 'lecturer', 'Calculus 2', 103, 'Cse');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `program_name` varchar(255) NOT NULL,
  `est_semester_duration` int(255) NOT NULL,
  `student_id` int(255) NOT NULL,
  `other_uni_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`program_name`, `est_semester_duration`, `student_id`, `other_uni_name`) VALUES
('SENT EXPO', 1, 64160001, 'AICTE'),
('TECH FEST 2021', 2, 64160002, 'IIT Bombay');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `birthdate` date NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `advisor_name` varchar(255) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `scholarship` varchar(255) NOT NULL,
  `grade` int(255) NOT NULL,
  `emp_type` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `name`, `birthdate`, `course_code`, `advisor_name`, `degree`, `scholarship`, `grade`, `emp_type`, `department`, `email`) VALUES
(64160001, 'Snehal Harsh', '2002-11-09', 'Database', 'Anil Kumar Meher', 'Undergrad', 'Full Scholarship', 3, 'Advanced Programming TA', 'Computer Science & Engineering', '20cse035@giet.edu'),
(64160002, 'Priya Khetan', '2002-10-20', 'Algorithm', 'Anil Kumar Meher', 'Undergrad', 'Full Scholarship', 3, 'Probability TA', 'Computer Science & Engineering', '20cse052@giet.edu'),
(64160018, 'Aayush Padhy', '1997-06-09', 'Machine Learning', 'Anil Kumar Meher', 'Grad', 'Half Scholarship', 1, 'NULL', 'Computer Science & Engineering', '20cse059@giet.edu'),
(64160022, 'Ananya', '1998-06-16', 'Microprocessor', 'Anil Kumar Meher', 'Phd', 'Half Scholarship', 4, 'Probability TA', 'Computer Science & Engineering', '20cse063@giet.edu');

-- --------------------------------------------------------

--
-- Table structure for table `student_book`
--

CREATE TABLE `student_book` (
  `student_id` int(255) NOT NULL,
  `book_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_book`
--

INSERT INTO `student_book` (`student_id`, `book_name`) VALUES
(64160001, 'Lord of The Rings'),
(64160002, 'Harry Potter');

-- --------------------------------------------------------

--
-- Table structure for table `student_club`
--

CREATE TABLE `student_club` (
  `club_name` varchar(255) NOT NULL,
  `leader_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_club`
--

INSERT INTO `student_club` (`club_name`, `leader_id`) VALUES
('GIETU Robotistics Club 2021', 64160014),
('NSS', 62160008),
('PDSC CLUB SEASON 8\n', 63150012),
('RSS(RASTRIYA SWAYAM SEWAK SANG)\n', 61170008);

-- --------------------------------------------------------

--
-- Table structure for table `student_club_participants`
--

CREATE TABLE `student_club_participants` (
  `leader_id` int(11) NOT NULL,
  `participant_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_club_participants`
--

INSERT INTO `student_club_participants` (`leader_id`, `participant_id`) VALUES
(61170008, 64160001),
(63150012, 64160002),
(64160014, 64160002);

-- --------------------------------------------------------

--
-- Table structure for table `student_current_course`
--

CREATE TABLE `student_current_course` (
  `course_name` varchar(255) NOT NULL,
  `student_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_current_course`
--

INSERT INTO `student_current_course` (`course_name`, `student_id`) VALUES
('Algorithm', 64160002),
('Database', 64160001);

-- --------------------------------------------------------

--
-- Table structure for table `student_exam`
--

CREATE TABLE `student_exam` (
  `exam_name` varchar(255) NOT NULL,
  `student_id` int(255) NOT NULL,
  `grade` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_exam`
--

INSERT INTO `student_exam` (`exam_name`, `student_id`, `grade`) VALUES
('Algorithm Final', 64160002, 80),
('Algorithm Midterm', 64160002, 90),
('Database Final', 64160001, 95),
('Database Midterm', 64160001, 85);

-- --------------------------------------------------------

--
-- Table structure for table `student_past_courses`
--

CREATE TABLE `student_past_courses` (
  `student_id` int(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `final_grade` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_past_courses`
--

INSERT INTO `student_past_courses` (`student_id`, `course_name`, `final_grade`) VALUES
(64160001, 'Introduction to Programing', 87),
(64160001, 'Object Oriented Programming', 86),
(64160002, 'Data Structures', 70),
(64160002, 'Introduction to Programming', 89),
(64160002, 'Object Oriented Programming', 98);

-- --------------------------------------------------------

--
-- Table structure for table `visitor`
--

CREATE TABLE `visitor` (
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visitor`
--

INSERT INTO `visitor` (`email`, `name`, `password`, `phone`, `type`) VALUES
('20cse035@giet.edu', 'Snehal Harsh', '25f9e794323b453885f5181f1b624d0b', '362958625', 'student'),
('20cse038@giet.edu', 'Piyush', 'd978add609ef1436acfa20d3ca06fc9e', '348946864', 'lecturer'),
('20cse044.aniketkumar@giet.edu', 'Aniket Kumar', '25f9e794323b453885f5181f1b624d0b', '7257906006', 'student'),
('20cse052@giet.edu', 'Priya Khetan', '25f9e794323b453885f5181f1b624d0b', '8260892367', 'student'),
('20cse059@giet.edu', 'Aayush Padhy', '16309356b4f0361240665680a7c95c1f', '9337300846', 'student'),
('20cse063@giet.edu', 'Ananya', 'f016313d09c1a933e8a99afc5129769d', '3458395033', 'student'),
('ahamsharma@giet.edu', 'Aham Sharma', '25f9e794323b453885f5181f1b624d0b', '94315879154', 'lecturer'),
('akashkumar@giet.edu', 'Akash Kumar', '25f9e794323b453885f5181f1b624d0b', '843974828', 'lecturer'),
('anilkumarmeher@giet.edu', 'Anil kumar Meher', '25f9e794323b453885f5181f1b624d0b', '8492579516', 'lecturer'),
('debashishrath@giet.edu', 'Debashish Rath', '25f9e794323b453885f5181f1b624d0b', '9748156748', 'lecturer'),
('j.ksingh@giet.edu', 'J.K Singh', '25f9e794323b453885f5181f1b624d0b', '848951795', 'lecturer'),
('lohitangsharma@giet.edu', 'Lohitang Sharma', '25f9e794323b453885f5181f1b624d0b', '7481691258', 'lecturer'),
('naveensikhera@giet.edu', 'Naveen Sikhera', '25f9e794323b453885f5181f1b624d0b', '2498563478', 'lecturer'),
('rabinarayandas@giet.edu', 'Rabi Narayan Das', '25f9e794323b453885f5181f1b624d0b', '1484195415', 'lecturer'),
('s.krathod@giet.edu', 'S.K Rathod', '25f9e794323b453885f5181f1b624d0b', '5874887419', 'lecturer'),
('sunilrathod@giet.edu', 'Sunil Rathod', '25f9e794323b453885f5181f1b624d0b', '9417282685', 'lecturer'),
('vinaythakur@giet.edu', 'Vinay Thakur', '25f9e794323b453885f5181f1b624d0b', '8492789465', 'lecturer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`library_name`,`book_name`,`author`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_name`);

--
-- Indexes for table `dining`
--
ALTER TABLE `dining`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`course_name`,`exam_name`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`program_name`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_book`
--
ALTER TABLE `student_book`
  ADD PRIMARY KEY (`student_id`,`book_name`);

--
-- Indexes for table `student_club`
--
ALTER TABLE `student_club`
  ADD PRIMARY KEY (`club_name`);

--
-- Indexes for table `student_club_participants`
--
ALTER TABLE `student_club_participants`
  ADD PRIMARY KEY (`leader_id`,`participant_id`);

--
-- Indexes for table `student_current_course`
--
ALTER TABLE `student_current_course`
  ADD PRIMARY KEY (`course_name`);

--
-- Indexes for table `student_exam`
--
ALTER TABLE `student_exam`
  ADD PRIMARY KEY (`exam_name`,`student_id`);

--
-- Indexes for table `student_past_courses`
--
ALTER TABLE `student_past_courses`
  ADD PRIMARY KEY (`student_id`,`course_name`);

--
-- Indexes for table `visitor`
--
ALTER TABLE `visitor`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dining`
--
ALTER TABLE `dining`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
